// CivicConnect AI - Frontend logic (fixed & improved)

const API_BASE_URL = "http://127.0.0.1:8000"; // backend URL

function getStoredAuth() {
  const token = localStorage.getItem("cc_token");
  const userJson = localStorage.getItem("cc_user");
  return {
    token,
    user: userJson ? JSON.parse(userJson) : null,
  };
}

function saveAuth(token, user) {
  localStorage.setItem("cc_token", token);
  localStorage.setItem("cc_user", JSON.stringify(user));
}

function clearAuth() {
  localStorage.removeItem("cc_token");
  localStorage.removeItem("cc_user");
}

async function authFetch(path, options = {}) {
  const { token } = getStoredAuth();
  const url = `${API_BASE_URL}${path}`;

  const finalOptions = {
    ...options,
    headers: {
      ...(options.headers || {}),
    },
  };

  if (token) {
    finalOptions.headers["Authorization"] = `Bearer ${token}`;
  }

  return fetch(url, finalOptions);
}

function requireRole(allowedRoles) {
  const { token, user } = getStoredAuth();
  if (!token || !user || !allowedRoles.includes(user.role)) {
    window.location.href = "login.html";
  }
  return { token, user };
}

function bindLogout() {
  const btn = document.getElementById("logoutBtn");
  if (!btn) return;
  btn.addEventListener("click", () => {
    clearAuth();
    window.location.href = "index.html";
  });
}

// ---------------- LOGIN ----------------

async function initLoginPage() {
  const form = document.getElementById("loginForm");
  const errorBox = document.getElementById("loginError");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.textContent = "";

    const formData = new FormData(form);
    const payload = {
      email: formData.get("email"),
      password: formData.get("password"),
    };

    try {
      const res = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        errorBox.textContent = data.detail || "Login failed.";
        return;
      }

      saveAuth(data.access_token, data.user);

      // redirect by role
      const role = data.user.role;
      if (role === "citizen") window.location.href = "dashboard.html";
      else if (role === "department") window.location.href = "department.html";
      else if (role === "admin") window.location.href = "admin.html";
      else window.location.href = "index.html";
    } catch (err) {
      console.error("Login error:", err);
      errorBox.textContent = "Cannot connect to server.";
    }
  });
}

// ---------------- REGISTER ----------------

async function initRegisterPage() {
  const form = document.getElementById("registerForm");
  const errorBox = document.getElementById("registerError");
  const successBox = document.getElementById("registerSuccess");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.textContent = "";
    successBox.textContent = "";

    const formData = new FormData(form);
    const password = formData.get("password");
    const confirm = formData.get("confirmPassword");

    if (password !== confirm) {
      errorBox.textContent = "Passwords do not match.";
      return;
    }

    const payload = {
      name: formData.get("name"),
      email: formData.get("email"),
      password: password,
    };

    try {
      const res = await fetch("http://127.0.0.1:8000/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        errorBox.textContent = data.detail || "Registration failed.";
        return;
      }

      successBox.textContent = "Registration successful. You can now log in.";
      form.reset();
    } catch (err) {
      console.error("Register error:", err);
      errorBox.textContent = "Cannot connect to server.";
    }
  });
}

// ---------------- CITIZEN DASHBOARD ----------------

async function initCitizenDashboard() {
  const { user } = requireRole(["citizen"]);
  bindLogout();

  const welcome = document.getElementById("citizenWelcome");
  if (welcome && user) {
    welcome.textContent = `Welcome, ${user.name}`;
  }

  await loadCitizenComplaints();
}

async function loadCitizenComplaints() {
  const list = document.getElementById("citizenComplaints");
  if (!list) return;
  list.innerHTML = "";

  try {
    const res = await authFetch("/complaints/my");
    const complaints = await res.json();

    complaints.forEach((c) => {
      const div = document.createElement("div");
      div.className = "cc-complaint-card";
      div.innerHTML = `<strong>${c.title}</strong><br>${c.description}`;
      list.appendChild(div);
    });
  } catch (err) {
    console.error("Load complaints error:", err);
  }
}

// ---------------- REPORT COMPLAINT ----------------

async function initReportPage() {
  requireRole(["citizen"]);
  bindLogout();

  const form = document.getElementById("reportForm");
  const errorBox = document.getElementById("reportError");
  const successBox = document.getElementById("reportSuccess");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.textContent = "";
    successBox.textContent = "";

    const formData = new FormData(form);

    try {
      const res = await authFetch("/complaints/", {
        method: "POST",
        body: formData,
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        errorBox.textContent = data.detail || "Could not submit complaint.";
        return;
      }

      successBox.textContent = "Complaint submitted successfully.";
      form.reset();
    } catch (err) {
      console.error("Complaint error:", err);
      errorBox.textContent = "Cannot connect to server.";
    }
  });
}

// ---------------- ROUTER ----------------

document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;

  switch (page) {
    case "login":
      initLoginPage();
      break;
    case "register":
      initRegisterPage();
      break;
    case "citizen-dashboard":
      initCitizenDashboard();
      break;
    case "report":
      initReportPage();
      break;
    default:
      bindLogout();
  }
});

