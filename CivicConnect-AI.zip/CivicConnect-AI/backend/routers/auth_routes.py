from fastapi import APIRouter, HTTPException
from database import SessionLocal
from models import User
from auth import hash_password, verify_password, create_token

router = APIRouter(prefix="/auth")

@router.post("/register")
def register(data: dict):
    db = SessionLocal()
    if db.query(User).filter(User.email == data["email"]).first():
        raise HTTPException(400, "Email already exists")

    user = User(
        name=data["name"],
        email=data["email"],
        password=hash_password(data["password"]),
        role="citizen"
    )
    db.add(user)
    db.commit()
    return {"message": "Registered"}

@router.post("/login")
def login(data: dict):
    db = SessionLocal()
    user = db.query(User).filter(User.email == data["email"]).first()

    if not user or not verify_password(data["password"], user.password):
        raise HTTPException(401, "Invalid credentials")

    token = create_token({"id": user.id, "role": user.role})

    return {
        "access_token": token,
        "user": {
            "id": user.id,
            "name": user.name,
            "role": user.role,
            "departmentName": user.department_name
        }
    }