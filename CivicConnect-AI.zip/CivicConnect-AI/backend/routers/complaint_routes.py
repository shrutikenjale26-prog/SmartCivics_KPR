from fastapi import APIRouter, UploadFile, File, Form
from database import SessionLocal
from models import Complaint

router = APIRouter(prefix="/complaints")

@router.post("/")
def create_complaint(
    title: str = Form(...),
    description: str = Form(...),
    image: UploadFile = File(None),
    audio: UploadFile = File(None)
):
    db = SessionLocal()

    complaint = Complaint(
        user_id=1,  # demo
        title=title,
        description=description,
        category="General",
        priority="Medium",
        status="Pending",
        department_assigned="Roads"
    )

    db.add(complaint)
    db.commit()
    return {"message": "Complaint created"}

@router.get("/my")
def my_complaints():
    db = SessionLocal()
    return db.query(Complaint).all()