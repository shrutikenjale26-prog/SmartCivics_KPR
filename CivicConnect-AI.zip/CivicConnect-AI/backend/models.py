from sqlalchemy import Column, Integer, String, Text, ForeignKey
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    email = Column(String(100), unique=True)
    password = Column(String(255))
    role = Column(String(20))
    department_name = Column(String(100))


class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String(255))
    description = Column(Text)
    category = Column(String(50))
    priority = Column(String(20))
    status = Column(String(20))
    department_assigned = Column(String(100))
    image_path = Column(String(255))
    audio_path = Column(String(255))
    response_note = Column(Text)